﻿using Proiect_Licitatie.Factory;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

namespace Proiect_Licitatie.MonitorPattern
{
    class AuctionMonitor
    {
        private Object monitorObject = new Object();
        private Object verifyObject = new Object();
        private Object startStopwatch = new Object();
        public volatile Stopwatch sw = new Stopwatch();

        public bool AuctionEnd = false;
        public Auction Auction { get; set; }
        public AUser CurrentClient { get; set; }

        public AuctionMonitor(Auction auction)
        {
            Auction = auction;
        }

        public void Bid( double price, AUser client)
        {
            try
            {
                Monitor.Enter(monitorObject);
                if (AuctionEnd)
                {
                    //  Console.WriteLine("Is finished at: {0}", sw.ElapsedMilliseconds);
                    return;
                }
                if (Auction.PriceCurrent >= price)
                {
                    //  Console.WriteLine("We received a lower price: {0}$ < {1}", price, Auction.PriceCurrent);
                    return;
                }
                CurrentClient = client;
                ((Client)CurrentClient).LastPriceCalled = price;
                Console.WriteLine("----------------------------------------------");
                Console.WriteLine("We have a new bid: {0}$ from: {1}", price, client.Username);
                Auction.PriceCurrent = price;
                lock (startStopwatch)
                {
                    Monitor.PulseAll(startStopwatch);
                }
            }
            finally
            {
                Monitor.Exit(monitorObject);
            }
        }

        public void Verify()
        {
            try
            {
                Monitor.Enter(verifyObject);
                lock (startStopwatch)
                {
                    Monitor.Wait(startStopwatch);
                }
                sw.Stop();
                sw.Reset();
                sw.Start();
            }
            finally
            {
                Monitor.Exit(verifyObject);
            }
        }

        /// <summary>
        /// It verifies if the time limit is reached after the last bid
        /// </summary>
        /// <returns></returns>
        public AUser VerifyAuctionEnd()
        {
            int[] vizited = new int[10];
            while (!this.AuctionEnd)
            {
                Thread.Sleep(100);
                if (this.sw.ElapsedMilliseconds > Auction.Limit * 1000)
                {
                    this.AuctionEnd = true;
                    this.Auction.NotifyAuctionEnd();
                    this.Auction.RemoveAll();
                    lock (startStopwatch)
                    {
                        Monitor.PulseAll(startStopwatch);
                    }
                }
            }
            return this.CurrentClient;
        }
    }
}
