﻿using Proiect_Licitatie.Factory;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Proiect_Licitatie.MonitorPattern
{
    class AuctionVerifier
    {
        private AuctionMonitor _auctionHandler;

        public AuctionVerifier(AuctionMonitor handler)
        {
            this._auctionHandler = handler;
        }

        public void Run()
        {
            while (!_auctionHandler.AuctionEnd)
            {
                _auctionHandler.Verify();
            }
        }

        public AUser VerifyAuctionEnd()
        {
            return _auctionHandler.VerifyAuctionEnd();
        }
    }
}
