﻿using Proiect_Licitatie.Factory;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Proiect_Licitatie.MonitorPattern
{
    class AuctionManager
    {
        private AuctionMonitor _auctionHandler;

        public AuctionManager(AuctionMonitor handler)
        {
            _auctionHandler = handler;
        }

        public void Run(int index, AUser client)
        {
            Random r = new Random();
            double price = r.Next(100,  400);
            _auctionHandler.Bid(price, client);
            Thread.Sleep(200);
            if (index == 12)
            {
                Thread.Sleep(2000);
            }
        }
    }
}
