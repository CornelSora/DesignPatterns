﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proiect_Licitatie.Factory
{
    class Vendor: AUser
    {
        public override void Update(Auction auction)
        {
            Console.WriteLine("Notified Vendor: The price of the vendor: {0} object is: {1}", Username, auction.PriceCurrent);
        }

        public override void NotifyAuctionEnd(Auction auction)
        {
            Console.WriteLine("Notified Vendor: The auction of the vendor: {0} is ended with the price: {0} from price: {1}", auction.Name, auction.PriceCurrent, auction.PriceStart);
        }
    }
}
