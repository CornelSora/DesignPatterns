﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proiect_Licitatie.Factory
{
    enum UserType
    {
        CLIENT,
        VENDOR
    }
}
