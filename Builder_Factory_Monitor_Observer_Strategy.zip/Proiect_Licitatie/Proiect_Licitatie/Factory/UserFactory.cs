﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proiect_Licitatie.Factory
{
    class UserFactory
    {
        public static AUser CreateUser(UserType userType)
        {
            if (userType == UserType.CLIENT)
            {
                return new Client();
            }
            else if (userType == UserType.VENDOR)
            {
                return new Vendor();
            }
            return new Client();
        }
    }
}
