﻿using Proiect_Licitatie.Observer;
using System;
using System.Collections.Generic;
using System.Text;

namespace Proiect_Licitatie.Factory
{
    class AUser : IObserver
    {
        private static int _id = 0;

        public int Id { get; set; }
        public string Username { get; set; }
        public Auction Auction { get; set; }

        public AUser()
        {
            this.Id = _id++;
        }

        public virtual void Update(Auction auction)
        {
            Console.WriteLine("Notified {0} of {1}'s change to {2:C}", Username, auction.Name, auction.PriceCurrent);
        }

        public virtual void NotifyAuctionEnd(Auction auction)
        {
            Console.WriteLine("Notified {0}: The auction is ended with the price: {1} from price: {2}", 
                this.Username, auction.PriceCurrent, auction.PriceStart);
        }
    }
}
