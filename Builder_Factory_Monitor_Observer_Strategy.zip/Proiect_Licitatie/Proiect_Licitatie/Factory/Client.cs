﻿using Proiect_Licitatie.Strategy;
using System;
using System.Collections.Generic;
using System.Text;

namespace Proiect_Licitatie.Factory
{
    class Client : AUser
    {
        public double LastPriceCalled { get; set; }

        public IPayStrategy PayStrategy { get; set; }

        public void Pay()
        {
            PayStrategy.Pay(this);
        }
    }
}
