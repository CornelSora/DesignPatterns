﻿using Proiect_Licitatie.Factory;
using Proiect_Licitatie.Observer;
using System;
using System.Collections.Generic;

namespace Proiect_Licitatie
{
    class Auction : Subject
    {
        public string Name { get; set; }
        public string AuctionObject { get; set; }
        public int Limit { get; set; }
        private double _currentPrice { get; set; }
        private double _startPrice;

        public AUser Vendor { get; set; }

        public double PriceStart
        {
            get
            {
                return _startPrice;
            }
            set
            {
                _startPrice = value;
                PriceCurrent = value;
                Vendor.Update(this);
            }
        }

        public double PriceCurrent
        {
            get { return _currentPrice; }
            set
            {
                if (_currentPrice < value)
                {
                    _currentPrice = value;
                    Notify();
                }
                if (_currentPrice == 0)
                {
                    _currentPrice = value;
                }
            }
        }

        public override void Notify()
        {
            foreach (IObserver o in _observers)
            {
                o.Update(this);
            }
        }

        public void NotifyAuctionEnd()
        {
            foreach (IObserver o in _observers)
            {
                o.NotifyAuctionEnd(this);
            }
            Vendor.NotifyAuctionEnd(this);
        }

        private Auction()
        {

        }

        public class Builder
        {
            private string name;
            private string auctionObject;
            private double priceStart;
            private int limit;
            private AUser vendor;
            private List<IObserver> observers = new List<IObserver>();

            public Builder(string name, string auctionObject, AUser vendor)
            {
                this.name = name;
                this.vendor = vendor;
                this.auctionObject = auctionObject;
                this.limit = 1;
            }

            public Builder setName(string name)
            {
                this.name = name;
                return this;
            }

            public Builder setAuctionObject(string auctionObject)
            {
                this.auctionObject = auctionObject;
                return this;
            }

            public Builder setStartingPrice(double startPrice)
            {
                this.priceStart = startPrice;
                return this;
            }

            public Builder attachUsers(List<AUser> users)
            {
                foreach (var user in users)
                {
                    observers.Add(user);
                }
                return this;
            }

            public Builder setLimitOfSeconds(int limit)
            {
                this.limit = limit;
                return this;
            }

            public Auction createAuction()
            {
                var auction = new Auction()
                {
                    AuctionObject = this.auctionObject,
                    Name = this.name,
                    Vendor = this.vendor,
                    PriceStart = this.priceStart,
                    Limit = this.limit
                };
                if (observers != null)
                {
                    auction._observers = observers;
                }
                return auction;
            }
        }
    }
}
