﻿using Proiect_Licitatie.Factory;
using System;
using System.Collections.Generic;
using System.Text;

namespace Proiect_Licitatie.Strategy
{
    class PayPalStrategy : IPayStrategy
    {
        public void Pay(AUser user)
        {
            try
            {
                var client = (Client)user;
                Console.WriteLine("The pay was done successfuly with paypal with the amount: {0}$ by {1}", client.LastPriceCalled, client.Username);
            }
            catch
            {
                
            }
        }
    }
}
