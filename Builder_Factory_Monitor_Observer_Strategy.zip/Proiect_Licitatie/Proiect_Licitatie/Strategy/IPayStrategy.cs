﻿using Proiect_Licitatie.Factory;
using System;
using System.Collections.Generic;
using System.Text;

namespace Proiect_Licitatie.Strategy
{
    interface IPayStrategy
    {
        void Pay(AUser user);
    }
}
