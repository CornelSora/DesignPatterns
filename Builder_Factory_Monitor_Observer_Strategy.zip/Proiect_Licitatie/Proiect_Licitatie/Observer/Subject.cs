﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proiect_Licitatie.Observer
{
    abstract class Subject
    {
        protected List<IObserver> _observers = new List<IObserver>();

        public void Register(IObserver observer)
        {
            _observers.Add(observer);
        }

        public void Remove(IObserver observer)
        {
            _observers.Remove(observer);
        }

        public void RemoveAll()
        {
            _observers.RemoveAll(item => item != null);
        }

        public abstract void Notify();
    }
}
