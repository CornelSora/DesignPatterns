﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Proiect_Licitatie.Observer
{
    interface IObserver
    {
        void Update(Auction auction);
        void NotifyAuctionEnd(Auction auction);
    }
}
