﻿using Proiect_Licitatie.Factory;
using Proiect_Licitatie.MonitorPattern;
using Proiect_Licitatie.Strategy;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Proiect_Licitatie
{
    class Program
    {
        static void Main(string[] args)
        {
            List<AUser> users = InitializeUsers();

            AUser vendor = UserFactory.CreateUser(UserType.VENDOR);
            vendor.Username = "vendor";

            Auction auction = new Auction.Builder("auction1", "computer", vendor)
                              .attachUsers(users)
                              .setLimitOfSeconds(2)
                              .createAuction();

            auction.PriceStart = 100;

            AuctionMonitor auctionHandler = new AuctionMonitor(auction);
            AuctionVerifier verifier = new AuctionVerifier(auctionHandler);
            StartVerifier(verifier);

            AuctionManager auctionSystem = new AuctionManager(auctionHandler);
            StartTestUsers(auctionSystem, users);
        }

        public static List<AUser> InitializeUsers()
        {
            List<AUser> users = new List<AUser>();
            AUser client1 = UserFactory.CreateUser(UserType.CLIENT);
            client1.Username = "client1";
            AUser client2 = UserFactory.CreateUser(UserType.CLIENT);
            client2.Username = "client2";
            AUser client3 = UserFactory.CreateUser(UserType.CLIENT);
            client3.Username = "client3";

            users.Add(client1);
            users.Add(client2);
            users.Add(client3);

            return users;
        }

        public static void StartVerifier(AuctionVerifier verifier)
        {
            Thread startVerifier = new Thread(() =>
            {
                verifier.Run();
            });

            startVerifier.Start();

            Thread threadSW = new Thread(() =>
            {
                var winnerUser = (Client)verifier.VerifyAuctionEnd();
                Console.WriteLine("The auction is won by: {0}", winnerUser.Username);
                Console.WriteLine("Choose the pay method: \n1. credit card; \n2. paypal");
                string type = Console.ReadLine();
                if (type == "1")
                {
                    winnerUser.PayStrategy = new CardPayStrategy();
                }
                else
                {
                    winnerUser.PayStrategy = new PayPalStrategy();
                }
                winnerUser.Pay();
                Console.ReadKey();
            });

            threadSW.Start();
        }

        public static void StartTestUsers(AuctionManager aSystem, List<AUser> users)
        {
            Parallel.For(0, 10, (index) =>
            {
                Random rnd = new Random();
                aSystem.Run(index, users[rnd.Next(0, 3)]);
            });
            //for (int i = 0; i < 10; i++)
            //{
            //    Random rnd = new Random();
            //    aSystem.Run(i, users[rnd.Next(0, 3)]);
            //}
        }
    }
}
